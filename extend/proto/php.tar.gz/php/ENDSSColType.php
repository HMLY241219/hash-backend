<?php
/**
 * Auto generated from poker_common.proto at 2023-06-08 09:49:25
 */

namespace {
/**
 * ENDSSColType enum
 */
final class ENDSSColType
{
    const EN_DSS_COL_TYPE_SINGLE = 1;
    const EN_DSS_COL_TYPE_SHUN_ZHI = 2;
    const EN_DSS_COL_TYPE_QING_SHUN = 3;
    const EN_DSS_COL_TYPE_YI_KE = 4;

    /**
     * Returns defined enum values
     *
     * @return int[]
     */
    public function getEnumValues()
    {
        return array(
            'EN_DSS_COL_TYPE_SINGLE' => self::EN_DSS_COL_TYPE_SINGLE,
            'EN_DSS_COL_TYPE_SHUN_ZHI' => self::EN_DSS_COL_TYPE_SHUN_ZHI,
            'EN_DSS_COL_TYPE_QING_SHUN' => self::EN_DSS_COL_TYPE_QING_SHUN,
            'EN_DSS_COL_TYPE_YI_KE' => self::EN_DSS_COL_TYPE_YI_KE,
        );
    }
}
}