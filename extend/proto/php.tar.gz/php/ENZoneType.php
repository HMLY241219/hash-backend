<?php
/**
 * Auto generated from poker_common.proto at 2023-06-08 09:49:25
 */

namespace {
/**
 * ENZoneType enum
 */
final class ENZoneType
{
    const EN_Zone_LouDi = 0;
    const EN_Zone_LuZhou = 1;
    const EN_Zone_YiBin = 2;
    const EN_Zone_LeShan = 3;
    const EN_Zone_ChengDu = 4;
    const EN_Zone_SiChuan = 5;

    /**
     * Returns defined enum values
     *
     * @return int[]
     */
    public function getEnumValues()
    {
        return array(
            'EN_Zone_LouDi' => self::EN_Zone_LouDi,
            'EN_Zone_LuZhou' => self::EN_Zone_LuZhou,
            'EN_Zone_YiBin' => self::EN_Zone_YiBin,
            'EN_Zone_LeShan' => self::EN_Zone_LeShan,
            'EN_Zone_ChengDu' => self::EN_Zone_ChengDu,
            'EN_Zone_SiChuan' => self::EN_Zone_SiChuan,
        );
    }
}
}