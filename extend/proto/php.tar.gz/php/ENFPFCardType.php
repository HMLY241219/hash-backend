<?php
/**
 * Auto generated from poker_common.proto at 2023-06-08 09:49:25
 */

namespace {
/**
 * ENFPFCardType enum
 */
final class ENFPFCardType
{
    const EN_FPF_CARD_TYPE_Lower = 0;
    const EN_FPF_CARD_TYPE_Upper = 1;

    /**
     * Returns defined enum values
     *
     * @return int[]
     */
    public function getEnumValues()
    {
        return array(
            'EN_FPF_CARD_TYPE_Lower' => self::EN_FPF_CARD_TYPE_Lower,
            'EN_FPF_CARD_TYPE_Upper' => self::EN_FPF_CARD_TYPE_Upper,
        );
    }
}
}