<?php
/**
 * Auto generated from poker_msg_cs.proto at 2023-06-08 09:49:25
 */

namespace {
/**
 * InterEventOnDoActionOver message
 */
class InterEventOnDoActionOver extends \ProtobufMessage
{
    /* Field index constants */
    const TYPE = 1;
    const DSS_DEST_ACTION = 3;

    /* @var array Field descriptors */
    protected static $fields = array(
        self::TYPE => array(
            'name' => 'type',
            'required' => false,
            'type' => \ProtobufMessage::PB_TYPE_INT,
        ),
        self::DSS_DEST_ACTION => array(
            'name' => 'dss_dest_action',
            'required' => false,
            'type' => '\PBDSSAction'
        ),
    );

    /**
     * Constructs new message container and clears its internal state
     */
    public function __construct()
    {
        $this->reset();
    }

    /**
     * Clears message values and sets default ones
     *
     * @return null
     */
    public function reset()
    {
        $this->values[self::TYPE] = null;
        $this->values[self::DSS_DEST_ACTION] = null;
    }

    /**
     * Returns field descriptors
     *
     * @return array
     */
    public function fields()
    {
        return self::$fields;
    }

    /**
     * Sets value of 'type' property
     *
     * @param integer $value Property value
     *
     * @return null
     */
    public function setType($value)
    {
        return $this->set(self::TYPE, $value);
    }

    /**
     * Returns value of 'type' property
     *
     * @return integer
     */
    public function getType()
    {
        $value = $this->get(self::TYPE);
        return $value === null ? (integer)$value : $value;
    }

    /**
     * Returns true if 'type' property is set, false otherwise
     *
     * @return boolean
     */
    public function hasType()
    {
        return $this->get(self::TYPE) !== null;
    }

    /**
     * Sets value of 'dss_dest_action' property
     *
     * @param \PBDSSAction $value Property value
     *
     * @return null
     */
    public function setDssDestAction(\PBDSSAction $value=null)
    {
        return $this->set(self::DSS_DEST_ACTION, $value);
    }

    /**
     * Returns value of 'dss_dest_action' property
     *
     * @return \PBDSSAction
     */
    public function getDssDestAction()
    {
        return $this->get(self::DSS_DEST_ACTION);
    }

    /**
     * Returns true if 'dss_dest_action' property is set, false otherwise
     *
     * @return boolean
     */
    public function hasDssDestAction()
    {
        return $this->get(self::DSS_DEST_ACTION) !== null;
    }
}
}